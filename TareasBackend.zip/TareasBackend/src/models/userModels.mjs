export const users = [
   /*
    {
        "id": 6,
        "name": "Maite",
        "password": "abc123"
    }
    */
];
